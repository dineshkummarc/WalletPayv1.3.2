module.exports = {
  replaceAttrValues: {
    '#000': '{props.fill}',
  },
};
